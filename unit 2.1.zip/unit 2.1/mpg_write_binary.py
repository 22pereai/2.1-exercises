#!/usr/bin/env python3

import pickle

FILENAME = "trips.bin"

def write_trips(mpg):
    with open(FILENAME, "wb") as file: # write to binary file
        pickle.dump(mpg, file)
    return mpg

def read_trips(mpglist):
    with open(FILENAME, "rb") as file: # read from binary file
        mpglist = pickle.load(file)
        print(mpglist)
    return mpglist

def list_trips(mpglist):
    print(mpglist)
    print()


def get_miles_driven():
    while True:
        miles_driven = float(input("Enter miles driven:   "))                    
        if miles_driven > 0:       
            return miles_driven
        else:
            print("Entry must be greater than zero. Please try again.\n")
            continue
    
def get_gallons_used():
    while True:
        gallons_used = float(input("Enter gallons of gas:   "))                    
        if gallons_used > 0:       
            return gallons_used
        else:
            print("Entry must be greater than zero. Please try again.\n")
            continue
        
def main():
    # display a welcome message
    print("The Miles Per Gallon application")
    print()


    more = "y"
    while more.lower() == "y":
        miles_driven = get_miles_driven()
        gallons_used = get_gallons_used()

        mpg = round((miles_driven / gallons_used), 2) # handle creation of mpg
        mpglist = [[miles_driven, gallons_used, mpg]]
        print("Distance  Gallons  MPG")
        print(mpglist[0])
        print()
        write_trips(mpg)
        read_trips(mpglist)
        print()
        
        more = input("More entries? (y or n): ")
    
    print("Bye")

if __name__ == "__main__":
    main()